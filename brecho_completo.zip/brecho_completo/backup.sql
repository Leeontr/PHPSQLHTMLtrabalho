INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Moletom Dahui', 'UNISSEX 

- Tecido: algodão, tecido grosso.

- Avarias: X

  - Medidas:

- 65cm de comprimento, 

- 120cm de busto 

- 60cm de comprimento da manga.

-- SE ATENTE AS MEDIDAS!', 85.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_0597-31741f72ed47f7156817437046557235-480-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Jaqueta Inverno Tribal (P)', 'UNISSEX 

- Tecido: fleece, com forro, tecido grosso,

- Avarias: X

  - Medidas:

- 70cm de comprimento, 

- 120cm de busto 

- 62cm de comprimento da manga.

-- SE ATENTE AS MEDIDAS!', 90.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_0219-9eae33eed1b99dc9b517431026691087-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Calça Pierre Cardin (40)', 'UNISSEX

- Tecido: algodão, tecido grosso.

- Avarias: X

- Medidas:

- 107cm de comprimento 

- 84cm de cintura,  

- 30cm de gancho

- 110cm de quadril

-- SE ATENTE AS MEDIDAS!', 129.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_9308-d89b7eed863d0732b917425047304398-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Jorts Tactel Anos 2000 (42)', 'UNISSEX

- Tecido: poliéster, tactel.

- Avarias: X

- Medidas:

- 70cm de comprimento 

- 84cm de cintura, sem esticar 

- 35cm de gancho

- 120cm de quadril

-- SE ATENTE AS MEDIDAS!', 69.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_9327-e5f5ebe2d268f053c817425042229517-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Jaquetinha de Fio Free Surf (P)', 'UNISSEX

- Tecido: acrilico, tecido grosso.

- Avarias: X

  - Medidas:

- 55cm de comprimento, 

- 120cm de busto 

- 60cm de compr. da manga 

-- SE ATENTE AS MEDIDAS!', 54.90, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_4096-9301d900377f42363617128700721680-480-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Colete Jeans Lee Vintage (G)', 'UNISSEX 

- Tecido: Algodão. tecido grosso

- Avarias: X

  - Medidas:

- 65cm de comprimento, 

- 120cm de busto 

 

-- SE ATENTE AS MEDIDAS!', 75.90, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_8994-f824aeba498408865d17419028199619-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Blusinha fofinha branquinha', '90 cm

100% algodao

vendas ocasionais com desconto aos sabados
90 cm

100% algodao

vendas ocasionais com desconto aos sabados
90 cm

100% algodao

vendas ocasionais com desconto aos sabados', 45.90, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/2d008a0e-ece1-4712-92f7-03c886eda99d-7097044a3247a9a9af17056987405893-480-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Moletom Dahui', 'UNISSEX 

- Tecido: algodão, tecido grosso.

- Avarias: X

  - Medidas:

- 65cm de comprimento, 

- 120cm de busto 

- 60cm de comprimento da manga.

-- SE ATENTE AS MEDIDAS!', 85.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_0597-31741f72ed47f7156817437046557235-480-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Jaqueta Inverno Tribal (P)', 'UNISSEX 

- Tecido: fleece, com forro, tecido grosso,

- Avarias: X

  - Medidas:

- 70cm de comprimento, 

- 120cm de busto 

- 62cm de comprimento da manga.

-- SE ATENTE AS MEDIDAS!', 90.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_0219-9eae33eed1b99dc9b517431026691087-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Calça Pierre Cardin (40)', 'UNISSEX

- Tecido: algodão, tecido grosso.

- Avarias: X

- Medidas:

- 107cm de comprimento 

- 84cm de cintura,  

- 30cm de gancho

- 110cm de quadril

-- SE ATENTE AS MEDIDAS!', 129.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_9308-d89b7eed863d0732b917425047304398-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Jorts Tactel Anos 2000 (42)', 'UNISSEX

- Tecido: poliéster, tactel.

- Avarias: X

- Medidas:

- 70cm de comprimento 

- 84cm de cintura, sem esticar 

- 35cm de gancho

- 120cm de quadril

-- SE ATENTE AS MEDIDAS!', 69.00, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_9327-e5f5ebe2d268f053c817425042229517-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Jaquetinha de Fio Free Surf (P)', 'UNISSEX

- Tecido: acrilico, tecido grosso.

- Avarias: X

  - Medidas:

- 55cm de comprimento, 

- 120cm de busto 

- 60cm de compr. da manga 

-- SE ATENTE AS MEDIDAS!', 54.90, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_4096-9301d900377f42363617128700721680-480-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Colete Jeans Lee Vintage (G)', 'UNISSEX 

- Tecido: Algodão. tecido grosso

- Avarias: X

  - Medidas:

- 65cm de comprimento, 

- 120cm de busto 

 

-- SE ATENTE AS MEDIDAS!', 75.90, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/img_8994-f824aeba498408865d17419028199619-640-0.webp');
INSERT INTO roupas (nome, descricao, preco, imagem) VALUES ('Blusinha fofinha branquinha', '90 cm

100% algodao

vendas ocasionais com desconto aos sabados
90 cm

100% algodao

vendas ocasionais com desconto aos sabados
90 cm

100% algodao

vendas ocasionais com desconto aos sabados', 45.90, 'https://acdn-us.mitiendanube.com/stores/001/486/362/products/2d008a0e-ece1-4712-92f7-03c886eda99d-7097044a3247a9a9af17056987405893-480-0.webp');
INSERT INTO configuracoes (chave, valor) VALUES ('banner', 'https://acdn-us.mitiendanube.com/stores/001/486/362/themes/luxury/1-img-1937126683-1682552120-17a73a2afbd5cd535cea86870cbe84781682552120-640-0.png?1172680398');
